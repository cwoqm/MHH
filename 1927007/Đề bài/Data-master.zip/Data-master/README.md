# CEA Open Data

## Data Structure
The datasets are categorized as `<Structure>_<Crop>`. `Structure` can be either `GH` (Greenhouse) or `VF` (Vertical Farms).
